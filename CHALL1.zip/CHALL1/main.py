from ast import And
import requests
import json
import sqlite3
from flask import Flask, render_template, request

#flag is LITCTF{} with the name inside
con = sqlite3.connect('data.db', check_same_thread=False)
app = Flask(__name__)

cur = con.cursor()
#comment
cur.execute('''DROP TABLE IF EXISTS names''')
cur.execute('''CREATE TABLE names (name text)''')
cur.execute(
    '''INSERT INTO names (name) VALUES ("night.seal") '''
)

def checkTitokID(id='hoaa.hanassii'):
    jsonStr = requests.get('https://www.tiktok.com/oembed?url=https://www.tiktok.com/@'+str(id)).text

    try:
        # parse json string
        pythonObj = json.loads(jsonStr)
    except:
        return False

    try: 
        code = pythonObj['code']
        if code == 400:
            # ID Not Found!
            return False
    except:
        # ID Found!
        return True

@app.route('/', methods=['GET', 'POST'])
def login():
    titokID = 'hoaa.hanassii'
    send = "index.html"

    if request.method == 'POST':

        titok_id = request.form['titok_id']

        try:
            cur.execute("SELECT * FROM names WHERE name='" + titok_id + "'")
        except:
            pass
	
        rows = cur.fetchall()

        if len(rows) > 0:
            if checkTitokID(titok_id):
                return render_template('index.html', error="Yes, this is my idol!!!", titokID=titok_id)
            else:
                return render_template('index.html', error="Yes, this is my idol!!!", titokID='haha@haha@haha')
        else:
            if checkTitokID(titok_id):
                return render_template('index.html', error="This is your titok idol!!! (｡•̀ᴗ-)✧", titokID=titok_id)
            else:
                return render_template('index.html', error="Couldn't find this account !!!", titokID='haha@haha@haha')

    return render_template(send, error="", titokID=titokID)

if __name__ == "__main__":
    app.run()

# ' OR name LIKE 'night.seal%' --