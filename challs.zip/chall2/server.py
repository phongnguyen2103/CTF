from urllib import request
from flask import Flask, request
from builtins import open as _, eval as _a
from unicodedata import normalize as _b
from re import search as _e

app = Flask(__name__)

def check_regex(pattern):
    if _e("[\\101-\\132\\141-\\172]", pattern):
        return False
    else:
        return True

@app.route('/')
def index():
    return '<h2>U think U can bypass regex, dreaming !!!</h2>'

@app.route('/payload')
def get_flag():
    try:
        if _e("[\\101-\\132\\141-\\172]", __ := _b("\116\106\113\104",request.args.get('cmd'))):
            return "/\/[]† 13@|) ßL|† \|/Я°/\/6"
        return _a(__)[0]
    except:
        return "/\/[]† 13@|) ßL|† \|/Я°/\/6"

app.run(debug=False, host='0.0.0.0')



