from flask import Flask, render_template, request, make_response

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/heyyou', methods = ['GET', 'POST'])
def setcookie():
    resp = make_response(render_template('miracle.html'))
    resp.set_cookie('miracle', 'em0t3t{th1s_c00k13_1s_m1r4cl3_1n_myst3ry}') 
    return resp

app.run(debug=False, host='0.0.0.0')